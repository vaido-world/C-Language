
/* FIXME
   here we putting #pragma warning and disable or enable them
   I known gcc and msvc using diffent pragma and I do not known
   the gcc pragma well to achive msvs and gcc compatible with this */